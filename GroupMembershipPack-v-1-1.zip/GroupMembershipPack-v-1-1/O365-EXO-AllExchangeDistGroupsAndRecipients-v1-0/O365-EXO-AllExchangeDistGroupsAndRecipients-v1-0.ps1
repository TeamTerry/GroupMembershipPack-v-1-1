﻿#############################################################################################################################
###                                                                                                                       ###
###  	Script by Terry Munro -                                                                                           ###
###     Technical Blog -               http://365admin.com.au                                                             ###
###     Webpage -                      https://www.linkedin.com/in/terry-munro/                                           ###
###     TechNet Gallery Scripts -      http://tinyurl.com/TerryMunroTechNet                                               ###
###     Facebook Profile -             https://www.facebook.com/TerryMunro365Admin                                        ###
###     Facebook Support Group -       https://www.facebook.com/groups/365Admin                                           ###
###                                                                                                                       ###
###     Support -                      http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365.html       ###
###                                    http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365_6.html     ###
###                                                                                                                       ###
###     TechNet Download link -        https://gallery.technet.microsoft.com/Group-Membership-Pack-for-845f0cb2           ###
###                                                                                                                       ###
###                                                                                                                       ###
###   - Pre-Requisites for Office 365 and Azure PowerShell -                                                              ###
###                                                                                                                       ###
###   - - Configure your PC for Office 365 Admin including MFA                                                            ###
###       - http://www.365admin.com.au/2017/01/how-to-configure-your-desktop-pc-for.html                                  ###
###                                                                                                                       ###
###   - - How to connect to Office 365 via PowerShell with MFA - Multi-Factor Authentication                              ###
###       - http://www.365admin.com.au/2017/07/how-to-connect-to-office-365-via.html                                      ###
###                                                                                                                       ###
###   - - Office 365 Connection Script with Modern Auth                                                                   ###
###       - https://gallery.technet.microsoft.com/Office-365-Connection-47e03052                                          ###
###                                                                                                                       ###
###     Version 1.0        - 03/07/2018                                                                                   ###
###                                                                                                                       ###
###                                                                                                                       ###
#############################################################################################################################



### Update the log path variables below before running the script ####

$logpath = "c:\reports"

######################################################################



$Groups = Get-Recipient -ResultSize Unlimited | where { $_.RecipientType -eq 'MailUniversalDistributionGroup' -Or $_.RecipientType -eq 'MailUniversalSecurityGroup' -and $_.RecipientTypeDetails -ne 'GroupMailbox' }
$Groups | ForEach-Object {
$Group = $_
Get-DistributionGroupMember -ResultSize Unlimited -Identity $_.distinguishedname  | ForEach-Object { 
 New-Object -TypeName PSObject -Property @{
       GroupDisplayName = $group.DisplayName
       GroupEmailAddress = $Group.PrimarySmtpAddress
       GroupRecipientTypeDetails = $Group.RecipientTypeDetails
       GroupManagedBy = $Group.ManagedBy
       GroupOnPremises = $Group.Capabilities
       MemberDisplayName = $_.DisplayName
       MemberEmailAddress = $_.PrimarySmtpAddress
       MemberUserPrincipalName = $_.WindowsLiveID
       MemberExternalEmailAddress = $_.ExternalEmailAddress
       MemberType = $_.RecipientTypeDetails
       MemberIsLicensed = $_.SkuAssigned
}
}
} | Select GroupDisplayName, GroupEmailAddress, GroupRecipientTypeDetails, GroupManagedBy, GroupOnPremises, MemberDisplayName, MemberEmailAddress, MemberUserPrincipalName, MemberExternalEmailAddress, MemberType, MemberIsLicensed |
Export-Csv -Path C:\Reports\AllExchangeOnline-DistributionGroupsAndMembers.csv -NoTypeInformation