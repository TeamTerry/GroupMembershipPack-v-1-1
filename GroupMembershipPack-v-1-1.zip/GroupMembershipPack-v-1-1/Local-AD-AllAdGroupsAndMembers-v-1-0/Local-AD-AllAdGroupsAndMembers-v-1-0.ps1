﻿#############################################################################################################################
###                                                                                                                       ###
###  	Script by Terry Munro -                                                                                           ###
###     Technical Blog -               http://365admin.com.au                                                             ###
###     Webpage -                      https://www.linkedin.com/in/terry-munro/                                           ###
###     TechNet Gallery Scripts -      http://tinyurl.com/TerryMunroTechNet                                               ###
###     Facebook Profile -             https://www.facebook.com/TerryMunro365Admin                                        ###
###     Facebook Support Group -       https://www.facebook.com/groups/365Admin                                           ###
###                                                                                                                       ###
###     Support -                      http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365.html       ###
###                                    http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365_6.html     ###
###                                                                                                                       ###
###     TechNet Download link -        https://gallery.technet.microsoft.com/Group-Membership-Pack-for-845f0cb2           ###
###                                                                                                                       ###
###                                                                                                                       ###
###   - Pre-Requisites for Office 365 and Azure PowerShell -                                                              ###
###                                                                                                                       ###
###   - - Configure your PC for Office 365 Admin including MFA                                                            ###
###       - http://www.365admin.com.au/2017/01/how-to-configure-your-desktop-pc-for.html                                  ###
###                                                                                                                       ###
###   - - How to connect to Office 365 via PowerShell with MFA - Multi-Factor Authentication                              ###
###       - http://www.365admin.com.au/2017/07/how-to-connect-to-office-365-via.html                                      ###
###                                                                                                                       ###
###   - - Office 365 Connection Script with Modern Auth                                                                   ###
###       - https://gallery.technet.microsoft.com/Office-365-Connection-47e03052                                          ###
###                                                                                                                       ###
###     Version 1.0        - 03/07/2018                                                                                   ###
###                                                                                                                       ###
###                                                                                                                       ###
#############################################################################################################################


##############################################################################################################################
###                                                                                                                        ###
###  	Script Notes for Local Active Directory and Exchange On-premises                                                   ###
###                                                                                                                        ###
###     *** Important - Run this script in Exchange Management Shell                                                       ###
###                                                                                                                        ###
###     *** Make sure you have installed the Active Directory Tools on the Exchange server or Admin PC your run this on    ###
###                                                                                                                        ###
###     *** The script will automatically import the PowerShell Active Directory module                                    ###
###                                                                                                                        ###
###     Update the variable - $logpath - to set the location you want the reports to be generated                          ###
###                                                                                                                        ###
##############################################################################################################################


### Note - This script queries the whole domain, not a specific OU and sub-OUs
### Note - This includes computer groups, everything ! 


### Update the log path variables below before running the script ####

$logpath = "c:\reports"

######################################################################

Import-Module ActiveDirectory


$Groups = Get-ADGroup -filter *
$Groups | ForEach-Object {
$Group = $_
Get-ADGroupMember -Identity $_.distinguishedname -Recursive | ForEach-Object { 
 New-Object -TypeName PSObject -Property @{
       GroupDisplayName = $group.Name
       GroupScope = $group.GroupScope
       GroupCategory = $Group.GroupCategory
       GroupDistinguishedName = $Group.DistinguishedName
       MemberDisplayName = $_.Name
       MemberSamAccountName = $_.SamAccountName
       MemberType = $_.objectClass
       MemberDistinguishedName = $_.DistinguishedName
}
}
} | Select GroupDisplayName, GroupScope, GroupCategory, GroupDistinguishedName, MemberDisplayName, MemberSamAccountName, MemberType, MemberDistinguishedName |
Export-Csv -Path C:\Reports\AllLocalADGroupsAndMembers.csv -NoTypeInformation
