﻿#############################################################################################################################
###                                                                                                                       ###
###  	Script by Terry Munro -                                                                                           ###
###     Technical Blog -               http://365admin.com.au                                                             ###
###     Webpage -                      https://www.linkedin.com/in/terry-munro/                                           ###
###     TechNet Gallery Scripts -      http://tinyurl.com/TerryMunroTechNet                                               ###
###     Facebook Profile -             https://www.facebook.com/TerryMunro365Admin                                        ###
###     Facebook Support Group -       https://www.facebook.com/groups/365Admin                                           ###
###                                                                                                                       ###
###     Support -                      http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365.html       ###
###                                    http://www.365admin.com.au/2018/07/group-membership-pack-for-office-365_6.html     ###
###                                                                                                                       ###
###     TechNet Download link -        https://gallery.technet.microsoft.com/Group-Membership-Pack-for-845f0cb2           ###
###                                                                                                                       ###
###                                                                                                                       ###
###   - Pre-Requisites for Office 365 and Azure PowerShell -                                                              ###
###                                                                                                                       ###
###   - - Configure your PC for Office 365 Admin including MFA                                                            ###
###       - http://www.365admin.com.au/2017/01/how-to-configure-your-desktop-pc-for.html                                  ###
###                                                                                                                       ###
###   - - How to connect to Office 365 via PowerShell with MFA - Multi-Factor Authentication                              ###
###       - http://www.365admin.com.au/2017/07/how-to-connect-to-office-365-via.html                                      ###
###                                                                                                                       ###
###   - - Office 365 Connection Script with Modern Auth                                                                   ###
###       - https://gallery.technet.microsoft.com/Office-365-Connection-47e03052                                          ###
###                                                                                                                       ###
###     Version 1.0        - 03/07/2018                                                                                   ###
###                                                                                                                       ###
###                                                                                                                       ###
#############################################################################################################################



### Update the log path variables below before running the script ####

$logpath = "c:\reports"

######################################################################



$Groups = Get-AzureADGroup -All $True 
$Groups | ForEach-Object {
$Group = $_
Get-AzureADGroupMember -All $True -ObjectID $Group.ObjectID | ForEach-Object {

New-Object -TypeName PSObject -Property @{
       GroupDisplayName = $group.DisplayName
       GroupObjectID = $Group.ObjectId
       GroupEmailAddress = $Group.Mail
       GroupIsSecurityEnabled = $Group.SecurityEnabled
       SyncedFromOnPremises = $Group.DirSyncEnabled
       MemberDisplayName = $_.DisplayName
       MemberUserPrincipalName = $_.UserPrincipalName
       MemberEmailAddress = $_.Mail
       MemberType = $_.UserType

}
}
} | Select-Object GroupDisplayName, GroupObjectID, GroupEmailAddress, GroupIsSecurityEnabled, SyncedFromOnPremises, MemberDisplayName, MemberUserPrincipalName, MemberEmailAddress, MemberType |

 Export-CSV "$logpath\AllAzureADGroupsAndMembers.csv" -NoTypeInformation 